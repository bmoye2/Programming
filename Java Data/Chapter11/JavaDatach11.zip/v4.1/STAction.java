public interface STAction
{
	public final static int ADDUSER = 1, UPDUSER = 2, DELUSER = 3, LISTUSERS = 4;
}
