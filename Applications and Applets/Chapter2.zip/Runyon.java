/*
    Chapter 2:  Runyon Corporation
    Programmer: Dean Priovolos
    Date:       September 17, 2008
    Filename:   Runyon.java
    Purpose:    This project displays the name,address, and
                web page address in a console application.
*/
 
public class Runyon 
{
    public static void main(String [] args)
    {
        System.out.println("The Runyon Corporation");
        System.out.println("233 West Main Suite 207");
        System.out.println("Concord, Indiana 46112");
        System.out.println("w.w.w.RunyonCorp.com"); // display web addres
        System.out.println();
    }
}