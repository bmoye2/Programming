/*
   Programmer: Brett Moye
   Date:       February 9, 2014
   Program:    Name and Date
   Course #:   COSC 1336
   Purpose:    To Display my Name and Address
*/

public class Brett
{
   public static void main(String [] args)
   {
      System.out.println("Brett");
      System.out.println("2508 E 11th Ave");
      System.out.println("Denver, CO");
   }
}   