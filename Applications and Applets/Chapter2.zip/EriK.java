/*
   Chapter 2:  Welcome to My Day
   Programmer: Eric Kantor
   Date:       October 4, 2007
   Filename:   Eric.java
   Purpose:    This project displays my name and address.
*/

public class EriK
{
   public static void main(String [] args)
   {
      System.out.println();
      System.out.println("Erik Kantor");
      System.out.println("10050 Glen Oak");
      System.out.println("Kansas City, MO 64110");
      System.out.println();
   }
}