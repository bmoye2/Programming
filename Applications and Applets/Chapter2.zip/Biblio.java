/*
   Programmer: Brett
   Date:       February 9, 2014
   Program:    Biblio
   Course Name:COSC 1336
   Purpose:    Writing Java code from a Flowchart
*/

public class Biblio
{
   public static void main(String [] args)
   {
      System.out.println("Name of the Book");
      System.out.println("Authors of the Book");
      System.out.println("Publication Data");
   }
}  
   